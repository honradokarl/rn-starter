import React from 'react'; // how to make different components together
import {Text, StyleSheet, View} from 'react-native'; // knows how to take the information from those component

const ComponentScreen = function () {

    const greeting = 'Bye there!';
    const greetingJSX = <Text>Hello to you!</Text>

    return <View>
        <Text style={styles.textStyle}>This is the component screen</Text>
        <Text>{ greeting }</Text>
        {greetingJSX}
    </View>;
};

const styles = StyleSheet.create({
     textStyle: {
        fontSize: 50
     }
});

export default ComponentScreen;